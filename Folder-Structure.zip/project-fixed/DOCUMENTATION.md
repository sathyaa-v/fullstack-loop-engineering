# Multi-Agent OpenCode Project — Documentation

Spring Boot + Angular 19 + Oracle, orchestrated by OpenCode with file-based
context engineering and an automated implementation loop. This document
explains the structure, the fixes applied to the original template, the loop
architecture, and how to run it day to day.

---

## 1. Folder structure

```
parent-project/
├── AGENTS.md                     # root rules, read by every agent
├── DOCUMENTATION.md              # this file
├── VERIFICATION.md               # human checklist: tests + things agents can't check
├── PROJECT-PLAN.md               # the "why" of context engineering, plus starter templates
├── opencode.json                 # agent registry, models, permissions, modes
│
├── .opencode/agent/
│   ├── orchestrator.md           # primary agent — requirements loop + loop controller
│   ├── backend.md                # subagent
│   ├── frontend.md               # subagent
│   ├── database.md               # subagent
│   └── verifier.md               # subagent — compile/build + requirement match check
│
├── requirements/
│   ├── REQ-TEMPLATE.md           # template, includes the Iteration Log section
│   ├── incoming/                 # staging area for raw, unprocessed asks
│   └── REQ-XXX-*.md              # requirement docs (created over time, track loop state)
│
├── shared-context/                # cross-module decisions
│   ├── memory.md
│   ├── plan.md
│   └── state.md
│
├── spring-boot-backend/
│   ├── AGENTS.md
│   ├── .context/{memory,plan,state}.md
│   └── src/...
│
├── angular-frontend/
│   ├── AGENTS.md
│   ├── .context/{memory,plan,state}.md
│   └── src/...
│
└── oracle-database/
    ├── AGENTS.md
    ├── .context/{memory,plan,state}.md
    └── sql/...
```

Every module folder is symmetric: one `AGENTS.md` (persona + conventions) and
one `.context/` folder with the same three files.

---

## 2. The three context files, and why each exists

| File | Question it answers | Update frequency |
|---|---|---|
| `memory.md` | What have we learned/decided, standing? | Rarely — only on new standing decisions |
| `plan.md` | What are we working toward right now? | When the Orchestrator assigns new work |
| `state.md` | Exactly where did we leave off? | Every session, without exception |

`shared-context/` holds the same three files for anything that crosses module
boundaries — an API contract, a schema change, a naming convention two agents
both need to know.

**Why this matters:** an agent's context window resets every session. Without
these files, you re-explain your architecture and past decisions every time
you open OpenCode. With them, an agent reads a handful of short files and is
caught up in seconds — which matters even more now that subagents are
dispatched automatically and have no chance to ask you clarifying questions
mid-loop.

---

## 3. What changed from the original template (and why)

### 3.1 `opencode.json` — model IDs and provider config were broken
The original config used bare model names with no provider prefix and no
`provider` block. **Fixed:** added a `litellm` provider block (OpenAI-
compatible SDK adapter) with `baseURL`/`apiKey` from environment variables,
and every agent's `model` field uses `litellm/<model-id>`.

```bash
export LITELLM_BASE_URL="https://your-litellm-proxy.example.com"
export LITELLM_API_KEY="sk-..."
```

### 3.2 Folder boundaries were instruction-only
**Fixed:** `permission.edit` path rules per agent in `opencode.json` — each
specialist can only write inside its own folder, `shared-context/`, and
`requirements/`. The verifier is more restricted still — it can only touch
`state.md` files and requirement docs. This is a hard technical constraint,
not a request.

### 3.3 / 3.4 Missing `.context/` files
`oracle-database/.context/` was empty; `angular-frontend/.context/` was
missing `plan.md`/`state.md`. **Fixed:** both are now complete and symmetric
with `spring-boot-backend/`.

### 3.5 Module `AGENTS.md` files were too thin
Angular's was missing Angular 19–specific idioms (`@if`/`@for`, signal
`input()`/`output()`, zoneless/`OnPush`, `@defer`). Oracle's had no naming,
migration, or indexing conventions. **Fixed:** both fleshed out.

### 3.6 `requirements/incoming/` was undocumented
**Fixed:** documented, and wired into the Orchestrator's loop as Step 0.

### 3.7 No control on `memory.md` growth
**Fixed:** every `AGENTS.md` has a concrete pruning rule (~150 lines →
fold into "Conventions", archive the rest).

### 3.8 Agents required manual switching for every step
The original design had five `primary` agents; you had to Tab between them
by hand at every step, including for the review/fix cycle. **Fixed:** see
§8 below — this is now a genuine automated loop.

### 3.9 Tests were gated by an agent that also wrote them
An earlier iteration had `backend`/`frontend` run their own test suite before
handoff, and the reviewer re-run it as a gate. **Reversed on request:** no
agent runs `mvn test`, `mvn verify`, `ng test`, or `ng e2e` anymore — this is
denied at the `bash` permission level, not just discouraged by instruction.
Running the actual test suite is entirely a human step. See §8.

---

## 4. Daily workflow

1. **New requirement arrives.** Talk to the Orchestrator directly, or drop a
   rough note in `requirements/incoming/` first if you want to think out loud.
2. **Start OpenCode** — `orchestrator` loads automatically (it's
   `default_agent` in `opencode.json`). It runs the Requirements Analysis
   Loop: clarifies the ask, analyzes cross-domain impact, drafts
   `requirements/REQ-XXX-*.md`, and **waits for your explicit approval.**
3. **On approval, it keeps going on its own.** You don't switch agents or do
   anything else — the Orchestrator dispatches `backend`/`frontend`/`database`
   as subagents for the modules involved, then dispatches `verifier`. If
   `verifier` finds issues, the Orchestrator dispatches a fix and re-verifies,
   once. See §8 for the full loop mechanics.
4. **The Orchestrator reports back** one of two outcomes: `Implemented —
   Pending Human Test Verification`, or `Blocked — Needs Human Review` with a
   specific list of what's still wrong after 2 attempts.
5. **You run `VERIFICATION.md`** — actual test suite execution, manual UI/API
   checks, migration execution against a real dev schema. No agent does this
   for you.
6. **You do the final review and commit.**

---

## 5. Setup checklist

- [ ] Install OpenCode: `curl -fsSL https://opencode.ai/install | bash`
- [ ] Set `LITELLM_BASE_URL` and `LITELLM_API_KEY` (or swap the `provider`
      block for a different provider, e.g. `anthropic`, if not using LiteLLM)
- [ ] Move your existing Spring Boot / Angular / Oracle code into the three
      subfolders as-is
- [ ] Run `opencode` from the parent folder, confirm `orchestrator` loads by
      default and can read `AGENTS.md`
- [ ] Confirm your OpenCode version supports `mode: "subagent"` and automatic
      task-tool dispatch from a primary agent (this is what makes the loop in
      §8 actually run without manual agent-switching) — check
      `opencode --version` against current docs if unsure
- [ ] Fill in the placeholders left in `.context/memory.md` files (styling
      convention, migration tool, testing framework)
- [ ] Commit `AGENTS.md`, `.opencode/`, `.context/`, `shared-context/`,
      `requirements/`, `opencode.json`, and this file to git
- [ ] Set a recurring reminder to prune `memory.md` files per the housekeeping
      rule in each `AGENTS.md`

---

## 6. Known placeholders you should fill in

- `angular-frontend/AGENTS.md` — styling approach, test runner (Jasmine+Karma
  vs Jest)
- `oracle-database/AGENTS.md` — exact Oracle version, migration tool
- `opencode.json` — provider block, if not using LiteLLM

---

## 7. Why the context files still matter with an automated loop

It might seem like `.context/state.md` matters less now that the Orchestrator
drives everything in one continuous session. It doesn't — two reasons:

- **Sessions still end.** The loop runs to completion for *one* requirement,
  then stops. The next requirement is a new session, and `.context/` files
  are how it picks up where the last one left off.
- **Subagents get fresh child sessions.** Per OpenCode's session-isolation
  model, a subagent's context does not automatically include the parent
  Orchestrator's full conversation — it sees only what's explicitly passed in
  the task invocation plus what it reads itself. That's exactly why
  `backend.md`/`frontend.md`/`database.md` all start with "read
  `.context/memory.md`, `.context/plan.md`, `.context/state.md` before
  starting" — without that instruction, a freshly spawned subagent would have
  no idea what happened in prior sessions.

---

## 8. The automated loop, in detail

### Agent modes
`opencode.json` now sets `"mode": "subagent"` for `backend`, `frontend`,
`database`, and `verifier`. Only `orchestrator` is `"mode": "primary"` — it's
the one agent you talk to, and the one agent with a `task` tool that can
invoke the others automatically based on their `description` fields and its
own instructions.

### The loop, step by step (see `.opencode/agent/orchestrator.md` for the
authoritative version)
1. Requirement approved → Orchestrator reads the REQ doc's Work Breakdown
   and dispatches `backend`/`frontend`/`database` for whichever modules are
   affected — this is iteration 1.
2. Once those return, Orchestrator dispatches `verifier` with the REQ doc and
   the list of changed modules.
3. `verifier` checks two things only: **does it compile/build** (`mvn
   compile`, `ng build` — never `mvn test`/`ng test`, those are permission-
   denied for it) and **does the code satisfy the REQ's acceptance
   criteria**, read directly against the diff. It returns `SATISFIED` or
   `NOT_SATISFIED` with an itemized, module-tagged issue list.
4. If `SATISFIED` → Orchestrator marks the REQ `Implemented — Pending Human
   Test Verification`, updates state files, stops, and tells you to run
   `VERIFICATION.md`.
5. If `NOT_SATISFIED` and this was iteration 1 → Orchestrator logs the issues
   in the REQ's Iteration Log, dispatches **only the specific subagent(s)
   responsible** for the flagged issues (iteration 2), and re-verifies.
6. If `NOT_SATISFIED` after iteration 2 → **hard stop.** No third attempt,
   ever. The REQ is marked `Blocked — Needs Human Review` with the specific
   unresolved issues, and the Orchestrator reports this to you directly.

The cap is 2 total implementation attempts per requirement — not per issue
individually. If iteration 1 surfaces three issues across two modules, all
three get one shared fix attempt in iteration 2, and if verifier still isn't
satisfied after that, the whole requirement stops rather than looping issue
by issue indefinitely.

### Why testing was pulled out of the automated loop entirely
This was a deliberate reversal from an earlier version of this template,
which had `backend`/`frontend` run their own tests and had the reviewer
re-run them as an approval gate. Two reasons that no longer holds:

1. **You asked for it explicitly** — test execution should be a human
   checkpoint, not something that happens unattended inside a loop that can
   run to completion without you watching.
2. **It fits the loop's design better anyway.** An automated loop with a hard
   iteration cap needs a fast, deterministic verifier — compilation and a
   direct requirement-vs-code comparison are exactly that. A full test run
   (especially anything involving a real Oracle schema) is slower, has more
   moving parts, and is a better fit for a human paying attention than for an
   unattended loop deciding on its own whether to retry.

The `verifier` subagent's `bash` permissions explicitly `deny` `mvn test`,
`mvn verify`, `ng test`, and `ng e2e` — same enforcement pattern as the
folder-boundary fix in §3.2, a hard technical block rather than a prose
request the model could drift from.

---

## 9. Why this is worth the overhead (and when it isn't)

**Worth it when:** the project spans more than one module and more than one
working session. The payoff now includes not needing to babysit every
agent-switch — you approve a requirement and get a finished-or-clearly-
blocked result back.

**Not worth it for:** a single-file script, a one-off prototype, or anything
you expect to finish in one sitting.
