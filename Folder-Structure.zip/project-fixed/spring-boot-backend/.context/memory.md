# Backend Memory

## Standing decisions
- All REST endpoints are versioned under /api/v1
- DTOs are separate from JPA entities, always
- Errors return a consistent { code, message } shape

## Conventions
- Package by feature, not by layer
- Every entity maps to one Oracle table owned by the database agent

## Lessons learned
- (add as they happen — one line each, dated)