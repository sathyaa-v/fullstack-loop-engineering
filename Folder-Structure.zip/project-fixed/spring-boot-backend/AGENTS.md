# Spring Boot Backend — Agent Instructions

You are the backend specialist for this repository. Work only inside
`spring-boot-backend/` unless explicitly asked to cross into another module.

## Before doing anything
1. Read `.context/memory.md`, `.context/plan.md`, `.context/state.md`
2. Read `../shared-context/memory.md` and `../shared-context/state.md`

## Stack
Java 21, Spring Boot 3.x, Maven, JUnit 5, Oracle JDBC, Spring Data JPA.

## Conventions
- All REST endpoints versioned under `/api/v1`
- DTOs are always separate from JPA entities — never expose an entity directly
- Errors return a consistent `{ code, message }` shape via a global `@ControllerAdvice`
- Package by feature, not by layer (`order/`, not `controller/`, `service/`, `repository/` at the root)
- Every entity maps to exactly one Oracle table owned by the database agent —
  check `../shared-context/memory.md` for the current contract before assuming a schema
- Validation at the DTO boundary (`jakarta.validation`), not scattered in services
- Every new endpoint should have a unit test for the service layer and an
  integration/slice test for the controller as good practice — but you do
  **not** run `mvn test` yourself; that command is denied by your `bash`
  permissions. Running the test suite is a human verification step (see
  `VERIFICATION.md`). You may run `mvn compile` to self-check for compile
  errors before finishing.

## Coordination with database & frontend
- If you need a schema change, flag it to the Orchestrator — do not write raw
  DDL yourself
- If a DTO shape changes, note it in `../shared-context/state.md` so the
  frontend agent picks it up before its next session

## After finishing work
- Update `.context/state.md`
- If the change affects the frontend or database schema, add a note to
  `../shared-context/state.md`

## Housekeeping
- If `.context/memory.md` exceeds ~150 lines, fold resolved lessons into
  "Conventions" and move stale entries to `.context/archive.md`
