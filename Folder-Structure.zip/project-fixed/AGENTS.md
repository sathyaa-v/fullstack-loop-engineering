# Multi-Agent OpenCode Project - Root Guidelines

This repository uses a multi-agent system powered by OpenCode + LiteLLM,
running as an automated loop: one primary agent (`orchestrator`) that talks
to you, plus four subagents it dispatches on its own once a requirement is
approved.

## Available Agents

- **orchestrator** (primary — the only one you interact with directly): runs
  requirements analysis with you, then automatically dispatches subagents and
  drives the fix/verify loop to completion without further input from you,
  up to a hard cap of 2 implementation iterations per requirement.
- **backend** (subagent): Spring Boot implementation, scoped to `spring-boot-backend/`
- **frontend** (subagent): Angular 19 implementation, scoped to `angular-frontend/`
- **database** (subagent): Oracle schema/migration work, scoped to `oracle-database/`
- **verifier** (subagent): checks compilation/build cleanliness and compares
  the implementation against the requirement's acceptance criteria. Does
  **not** run the test suite.

Folder boundaries are enforced two ways: by instruction (each module's
`AGENTS.md`) and technically, via the `permission.edit` rules in
`opencode.json`, which deny each specialist write access outside its own
folder (plus `shared-context/` and `requirements/`).

## Workflow

1. New requirement → drop a note in `requirements/incoming/` (optional) and
   talk to the **Orchestrator** — it's the default agent on startup.
2. Orchestrator performs analysis and gets your approval, producing
   `requirements/REQ-XXX-*.md`.
3. **From here, it runs automatically:** the Orchestrator dispatches
   `backend`/`frontend`/`database` for the modules the requirement affects,
   then dispatches `verifier` to check the result.
4. If `verifier` reports `NOT_SATISFIED`, the Orchestrator dispatches only the
   responsible subagent(s) to fix the specific issue, then re-verifies. This
   can happen **once** — 2 implementation attempts total per requirement,
   hard capped, no exceptions.
5. If still not satisfied after 2 attempts, the Orchestrator stops, marks the
   requirement `Blocked — Needs Human Review`, and reports exactly what's
   unresolved. Otherwise it marks it `Implemented — Pending Human Test
   Verification` and stops.
6. **You run the actual test suite and final verification.** No agent runs
   `mvn test`/`ng test`/`mvn verify`/`ng e2e` — those commands are denied by
   permission config, not just discouraged by instruction. See
   `VERIFICATION.md` for what to check.
7. Human final review and commit.

## Important Rules

- Never work across module boundaries unless dispatched there by the Orchestrator.
- Always read the relevant `.context/` files and `shared-context/` before starting work.
- Update `state.md` at the end of every session.
- Follow the guidelines defined in each module's `AGENTS.md`.
- Keep `memory.md` files lean: once a file passes ~150 lines, fold resolved
  items into "Conventions" and move stale entries to a local `archive.md`.
  Do this at least weekly.
- No agent, including the verifier, runs the test suite automatically. That's
  intentional — see `VERIFICATION.md` and `DOCUMENTATION.md` §8 for why.

## Environment

Set these before running OpenCode (see `opencode.json`):
- `LITELLM_BASE_URL` — your LiteLLM proxy endpoint
- `LITELLM_API_KEY` — credential for that endpoint

See `DOCUMENTATION.md` for the full setup guide, the loop architecture in
detail, and the session workflow.
