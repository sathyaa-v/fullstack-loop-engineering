# Shared Memory - Cross Module Decisions

## Standing Decisions
- All REST endpoints are versioned under `/api/v1`
- DTOs are used for all API communication between backend and frontend
- Database schema changes must be coordinated through the database agent

## Key Conventions
- Backend and Frontend must stay in sync on API contracts
- Major architectural decisions should be recorded here

## Lessons Learned
- (Add important cross-cutting lessons here)