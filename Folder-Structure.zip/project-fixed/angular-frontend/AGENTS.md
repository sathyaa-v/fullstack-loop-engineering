# Angular Frontend — Agent Instructions

You are the frontend specialist. Work only inside `angular-frontend/`.

## Before starting
Read `.context/memory.md`, `.context/plan.md`, `.context/state.md`, then
`../shared-context/memory.md` and `../shared-context/state.md`.

## Stack
Angular 19, TypeScript (strict mode), standalone components (no NgModules),
Signals for state, RxJS only for async streams that genuinely need it.

## Angular 19 conventions (use these, not the old patterns)
- Standalone components everywhere — no `NgModule` declarations
- Control flow: use built-in `@if` / `@for` / `@switch` — never `*ngIf` / `*ngFor` / `*ngSwitch`
- Reactivity: `signal()`, `computed()`, `effect()` for local/component state
- Component I/O: `input()` / `output()` function-based APIs, not `@Input()` / `@Output()` decorators
- Change detection: assume zoneless / `OnPush` — never rely on implicit zone.js dirty-checking
- Lazy/deferred views: `@defer` blocks for below-the-fold or heavy components
- Dependency injection: `inject()` function in field initializers over constructor injection where practical
- HTTP: `HttpClient` via `provideHttpClient()`, typed responses matching backend DTOs exactly
- Styling: (fill in — e.g. Tailwind / Angular Material / SCSS module convention)
- Testing: Jasmine + Karma or Jest (confirm which). Writing a spec per
  component/service is good practice, but you do **not** run `ng test`
  yourself; that command is denied by your `bash` permissions. Running the
  test suite is a human verification step (see `VERIFICATION.md`). You may
  run `ng build` to self-check for build/syntax errors before finishing.

## API contract discipline
- Never hand-type a response shape that duplicates a backend DTO — check
  `../shared-context/memory.md` for the current contract before writing a service
- If a needed field/endpoint doesn't exist yet, flag it to the Orchestrator rather
  than guessing the shape

## After work
- Update `.context/state.md`
- If backend contracts changed (new/renamed fields, endpoints), add a note to
  `../shared-context/state.md` and notify the Orchestrator

## Housekeeping
- If `.context/memory.md` exceeds ~150 lines, fold resolved lessons into
  "Conventions" and move stale entries to `.context/archive.md`
