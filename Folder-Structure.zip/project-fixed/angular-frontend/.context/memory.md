# Frontend Memory

## Standing decisions
- Use standalone components
- Prefer Signals for state management
- Follow design system and accessibility guidelines

## Lessons learned
- (Add as needed)