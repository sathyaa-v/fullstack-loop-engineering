# Frontend Plan

## Current Goal
- (Updated by Orchestrator after each approved requirement)

## In Progress
- None

## Depends on
- spring-boot-backend: API contracts (DTO shapes, endpoint paths) — check `../shared-context/plan.md` first
