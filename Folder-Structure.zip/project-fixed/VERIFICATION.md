# Verification Checklist

The `verifier` subagent automatically checks two things for every
requirement: that the changed code **compiles/builds cleanly** (`mvn
compile` for backend, `ng build` for frontend), and that the implementation
**matches the requirement's acceptance criteria**. It does not, and will
never, run the actual test suite — no agent in this project runs `mvn test`,
`mvn verify`, `ng test`, or `ng e2e` (these are denied at the permission
level in `opencode.json`, not just discouraged by instruction). Running
tests and final functional sign-off are entirely your job. Use this
checklist after the Orchestrator reports a requirement as "Implemented —
Pending Human Test Verification."

## Backend (Spring Boot)

Already done automatically by the `verifier` subagent (check its notes in
`shared-context/state.md` or the REQ document's Iteration Log):
- [ ] `mvn compile` succeeded
- [ ] Implementation matches the REQ's acceptance criteria

Your job:
- [ ] Run `mvn test` yourself and confirm it passes
- [ ] `mvn spring-boot:run` — app boots without errors
- [ ] `GET /actuator/health` returns `UP`
- [ ] Hit the specific changed endpoint (curl/Postman) and confirm the
      response shape matches `shared-context/memory.md`
- [ ] Check application logs for unexpected warnings/stack traces during the
      manual hit above

## Frontend (Angular 19)

Already done automatically by the `verifier` subagent:
- [ ] `ng build` succeeded
- [ ] Implementation matches the REQ's acceptance criteria

Your job:
- [ ] Run `ng test --watch=false` yourself and confirm it passes
- [ ] `ng serve`, open the changed screen/component in a browser
- [ ] Exercise the actual user flow the change was meant to support
- [ ] Check the browser console for errors/warnings
- [ ] If the component calls the backend, confirm the request/response in
      devtools Network tab matches the expected contract

## Database (Oracle)

Fully your job — no agent executes SQL against a real schema:
- [ ] Run the new/changed migration against a scratch or dev schema (never
      directly against a shared environment)
- [ ] Confirm it applies without errors
- [ ] Confirm it's additive, not destructive, unless the requirement
      explicitly called for a breaking change (dropped/renamed column,
      changed type on a populated table)
- [ ] If backend code depends on this schema change, confirm you ran the
      backend's tests against the updated schema, not a stale one

## Cross-module

- [ ] `shared-context/state.md` reflects the change (contract updates,
      breaking changes, anything the other agents need to know)
- [ ] If backend and frontend both changed in the same requirement, confirm
      the DTO shape on one side actually matches the TypeScript interface on
      the other — this is the single most common drift point and the
      easiest thing for an agent to get subtly wrong

## Before commit

- [ ] Verifier subagent gave an explicit verdict (SATISFIED / NOT_SATISFIED) —
      see the REQ document's Iteration Log, or `.opencode/agent/verifier.md`
      for what it checks
- [ ] Every item the verifier flagged has been addressed, or the requirement
      is knowingly `Blocked — Needs Human Review` and you're picking it up
      from there
- [ ] `git diff` reviewed by a human — agents write the code, a human still
      signs off on what ships
