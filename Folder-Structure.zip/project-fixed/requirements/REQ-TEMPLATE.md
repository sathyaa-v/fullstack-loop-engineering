# REQ-XXX: [Short Title]

**Date**: YYYY-MM-DD  
**Status**: Draft / In Review / Approved  
**Orchestrator**: 

## 1. Business Requirement
[What the user asked for in plain language]

## 2. Acceptance Criteria
- [ ] ...
- [ ] ...

## 3. Cross-Domain Impact Analysis

### Backend (Spring Boot)
- Affected components:
- New endpoints / services:
- DTO changes:
- Dependencies on Database:

### Frontend (Angular 19)
- Affected components / pages:
- New services / state:
- UI changes:
- Dependencies on Backend contracts:

### Database (Oracle)
- New / modified tables or columns:
- Indexes / constraints:
- Migration needed:
- Dependencies:

## 4. Interfaces & Contracts
- API Contract (Backend ↔ Frontend):
- Database Contract (Backend ↔ Database):

## 5. Work Breakdown

### Backend Tasks
- [ ] ...

### Frontend Tasks
- [ ] ...

### Database Tasks
- [ ] ...

## 6. Risks & Open Questions
- ...

## 7. Recommended Sequencing
1. ...
2. ...

## 8. Iteration Log (Orchestrator/Verifier use — do not fill in manually)

> Max 2 implementation iterations. Iteration 1 = initial implementation.
> Iteration 2 = fix pass if the verifier reported issues. If still
> NOT_SATISFIED after iteration 2, status becomes "Blocked — Needs Human
> Review" and the loop stops.

### Iteration 1
- Modules dispatched:
- Verifier verdict: (SATISFIED / NOT_SATISFIED)
- Issues reported (if any):

### Iteration 2 (only if iteration 1 was NOT_SATISFIED)
- Modules re-dispatched:
- Verifier verdict: (SATISFIED / NOT_SATISFIED)
- Issues reported (if any):

### Final status
- (Implemented — Pending Human Test Verification / Blocked — Needs Human Review)