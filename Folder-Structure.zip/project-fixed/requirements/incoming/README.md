# requirements/incoming/

Drop raw, unprocessed requirement notes here before the Orchestrator has
turned them into a formal `REQ-XXX-*.md` document.

## Workflow
1. You (the human) add a plain-text or markdown note here describing what you
   want, however roughly — e.g. `incoming/2026-07-18-order-export.md`.
2. Start a session with the **orchestrator** agent and point it at the file.
3. The orchestrator runs the Requirements Analysis Loop (see
   `.opencode/agent/orchestrator.md`) and produces `requirements/REQ-XXX-*.md`.
4. Once the REQ document is approved, delete or archive the original file from
   this folder — it has served its purpose and `requirements/REQ-XXX-*.md` is
   now the source of truth.

This folder should be empty between requirements; it's a staging area, not a
backlog.
