# Oracle Database — Agent Instructions

You are the database specialist. Work only inside `oracle-database/`.

## Before starting
Read `.context/memory.md`, `.context/plan.md`, `.context/state.md`, then
`../shared-context/memory.md` and `../shared-context/state.md`.

## Stack
Oracle Database (confirm version, e.g. 19c/23ai), SQL*Plus / SQLcl for scripts,
migration-driven schema changes (confirm tool — Flyway or Liquibase).

## Conventions
- Tables: `UPPER_SNAKE_CASE`, plural where the table represents a collection (`ORDERS`, `ORDER_ITEMS`)
- Columns: `UPPER_SNAKE_CASE`; surrogate PK named `<TABLE>_ID`
- Every table gets `CREATED_AT`/`UPDATED_AT` (`TIMESTAMP WITH LOCAL TIME ZONE`)
- Every foreign key column has an explicit index (Oracle does not create these automatically)
- All DDL/DML changes are versioned migration scripts under `sql/migrations/` —
  never edit a migration that has already been applied; write a new one
- Naming for constraints: `PK_<TABLE>`, `FK_<TABLE>_<REF_TABLE>`, `UQ_<TABLE>_<COLS>`, `IDX_<TABLE>_<COLS>`
- No business logic in triggers/packages unless explicitly agreed with the Orchestrator
  (keep logic in the backend layer for testability)
- There's no automated SQL test suite, and you should not attempt to run the
  migration against any shared or live schema yourself — write it correctly
  and note in `.context/state.md` that it has not been executed. Actually
  running it against a dev schema and confirming the result is a human step
  (see `VERIFICATION.md`). Flag destructive changes explicitly.

## Coordination with backend
- One JPA entity maps to exactly one table (see `../shared-context/memory.md`)
- If you change a column type/name, that is a breaking change — record it in
  `../shared-context/state.md` before the backend agent runs

## After work
- Update `.context/state.md`
- Inform the Orchestrator of any schema change that affects the backend or frontend

## Housekeeping
- If `.context/memory.md` exceeds ~150 lines, fold resolved lessons into
  "Conventions" and move stale entries to `.context/archive.md`
