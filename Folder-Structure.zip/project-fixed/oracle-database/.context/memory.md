# Database Memory

## Standing decisions
- Every table has a surrogate primary key (`<table>_ID`, `NUMBER`, `GENERATED ALWAYS AS IDENTITY`)
- Naming: tables `UPPER_SNAKE_CASE` singular-domain plural (e.g. `ORDERS`), columns `UPPER_SNAKE_CASE`
- All schema changes go through versioned migration scripts — never edit a shipped migration
- Every foreign key has a matching index (Oracle does not auto-index FKs)
- Timestamps: `CREATED_AT`, `UPDATED_AT` (`TIMESTAMP WITH LOCAL TIME ZONE`) on every table

## Conventions
- One schema owner per bounded context; cross-schema grants documented in this file when created
- Migration tool: (fill in — e.g. Flyway `V<version>__<description>.sql` under `sql/migrations/`)
- No application code executes dynamic DDL at runtime

## Lessons learned
- (add as they happen — one line each, dated)

---
> Prune this file when it exceeds ~150 lines: fold resolved lessons into "Conventions"
> and archive anything no longer relevant to `oracle-database/.context/archive.md`.
