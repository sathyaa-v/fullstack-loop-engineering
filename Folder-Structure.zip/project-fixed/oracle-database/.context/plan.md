# Database Plan

## Current Goal
- (Updated by Orchestrator after each approved requirement)

## In Progress
- None

## Depends on / feeds
- spring-boot-backend: entity ↔ table mapping must match this plan before backend work starts
